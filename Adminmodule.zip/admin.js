const API_BASE = "http://127.0.0.1:5000/api";

// ── Token Helper ─────────────────────────────────────────────────────────────
function getToken() {
  return localStorage.getItem('token');
}

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${getToken()}`
  };
}

// ── Add Question ─────────────────────────────────────────────────────────────
async function addQuestion() {
  const topic         = document.getElementById('q-topic').value.trim();
  const difficulty    = document.getElementById('q-difficulty').value;
  const text          = document.getElementById('q-text').value.trim();
  const correctOption = document.getElementById('q-correct').value;

  if (!topic || !text) {
    showToast('Topic and question text are required.', 'error');
    return;
  }

  const btn = document.getElementById('btn-add-question');
  btn.disabled = true;
  btn.textContent = 'Adding…';

  try {
    const res = await fetch(`${API_BASE}/add_question`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        topic,
        difficulty: parseInt(difficulty),
        text,
        correct_option: parseInt(correctOption)
      })
    });

    const data = await res.json();

    if (res.ok) {
      showToast(`✓ Question added (ID: ${data.id})`, 'success');
      document.getElementById('addQuestionForm').reset();
    } else {
      showToast(data.error || 'Failed to add question.', 'error');
    }
  } catch (err) {
    showToast('Network error. Is the server running?', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Add Question';
  }
}

// ── Load Users ────────────────────────────────────────────────────────────────
async function loadUsers() {
  const tbody = document.getElementById('users-tbody');
  tbody.innerHTML = `<tr><td colspan="3" class="loading-cell">Loading…</td></tr>`;

  try {
    const res = await fetch(`${API_BASE}/users`, {
      headers: authHeaders()
    });

    const data = await res.json();

    if (!res.ok) {
      tbody.innerHTML = `<tr><td colspan="3" class="error-cell">${data.error || 'Error loading users.'}</td></tr>`;
      return;
    }

    if (data.length === 0) {
      tbody.innerHTML = `<tr><td colspan="3" class="empty-cell">No users found.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.map(user => `
      <tr data-id="${user.id}">
        <td>${user.id}</td>
        <td>${escapeHtml(user.username)}</td>
        <td><span class="role-badge role-${user.role}">${user.role}</span></td>
        <td>
          <button class="btn-delete" onclick="deleteUser(${user.id}, '${escapeHtml(user.username)}')">
            Delete
          </button>
        </td>
      </tr>
    `).join('');

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="3" class="error-cell">Network error.</td></tr>`;
  }
}

// ── Delete User ───────────────────────────────────────────────────────────────
async function deleteUser(userId, username) {
  if (!confirm(`Delete user "${username}"? This cannot be undone.`)) return;

  try {
    const res = await fetch(`${API_BASE}/delete_user`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ user_id: userId })
    });

    const data = await res.json();

    if (res.ok) {
      showToast(`✓ ${data.msg}`, 'success');
      // Remove row from table without re-fetching
      const row = document.querySelector(`tr[data-id="${userId}"]`);
      if (row) row.remove();
    } else {
      showToast(data.error || 'Delete failed.', 'error');
    }
  } catch (err) {
    showToast('Network error.', 'error');
  }
}

// ── Toast Notification ────────────────────────────────────────────────────────
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  // Animate in
  requestAnimationFrame(() => toast.classList.add('toast-show'));

  setTimeout(() => {
    toast.classList.remove('toast-show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── Escape HTML ───────────────────────────────────────────────────────────────
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── Init ───────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  if (!getToken()) {
    window.location.href = 'index.html';
    return;
  }
  loadUsers();
});
