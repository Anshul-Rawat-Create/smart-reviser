from flask import Blueprint, request, jsonify
from app.models.user import User
from app.models.question import Question
from app import db
from functools import wraps

admin_bp = Blueprint('admin', __name__)

# ── Auth Guard ──────────────────────────────────────────────────────────────
def admin_required(f):
    """Decorator: checks that the request carries a valid admin session token."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({'error': 'Missing token'}), 401

        user = User.query.filter_by(session_token=token).first()
        if not user:
            return jsonify({'error': 'Invalid token'}), 401
        if user.role != 'admin':
            return jsonify({'error': 'Admin access required'}), 403

        request.admin_user = user
        return f(*args, **kwargs)
    return decorated


# ── Route 1: Add Question ────────────────────────────────────────────────────
@admin_bp.route('/add_question', methods=['POST'])
@admin_required
def add_question():
    """
    POST /api/add_question
    Body: { topic, difficulty, text, correct_option }
    Returns: { msg, id }
    """
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No JSON body provided'}), 400

    required = ['topic', 'difficulty', 'text', 'correct_option']
    missing = [field for field in required if field not in data]
    if missing:
        return jsonify({'error': f'Missing fields: {", ".join(missing)}'}), 400

    try:
        question = Question(
            topic=data['topic'],
            difficulty=int(data['difficulty']),
            text=data['text'],
            correct_option=int(data['correct_option'])
        )
        db.session.add(question)
        db.session.commit()
        return jsonify({'msg': 'Question added successfully', 'id': question.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ── Route 2: List All Users ──────────────────────────────────────────────────
@admin_bp.route('/users', methods=['GET'])
@admin_required
def list_users():
    """
    GET /api/users
    Header: Authorization: Bearer <AdminToken>
    Returns: [ { id, username, role } ]
    """
    try:
        users = User.query.all()
        users_list = [
            {'id': u.id, 'username': u.username, 'role': u.role}
            for u in users
        ]
        return jsonify(users_list), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Route 3: Delete User ─────────────────────────────────────────────────────
@admin_bp.route('/delete_user', methods=['POST'])
@admin_required
def delete_user():
    """
    POST /api/delete_user
    Body: { user_id }
    Returns: { msg }
    """
    data = request.get_json()
    if not data or 'user_id' not in data:
        return jsonify({'error': 'user_id is required'}), 400

    user_id = data['user_id']

    # Prevent admin from deleting themselves
    if user_id == request.admin_user.id:
        return jsonify({'error': 'Cannot delete your own admin account'}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404

    try:
        db.session.delete(user)
        db.session.commit()
        return jsonify({'msg': f'User "{user.username}" deleted successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
